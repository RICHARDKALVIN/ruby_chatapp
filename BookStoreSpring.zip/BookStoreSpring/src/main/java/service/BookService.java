package service;

import model.Book;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class BookService {
    private List<Book> list = new ArrayList<>();

    public void addbook(Book book) {
        list.add(book);
    }

    public List<Book> getBook() {
        return list;
    }

    public Book search(String bookname) {
        return list.stream()
                   .filter(b -> b.getBookname().equalsIgnoreCase(bookname))
                   .findFirst()
                   .orElse(null);
    }

    public void removebook(String booknamee, int id) {
        list.removeIf(b -> b.getBookname().equalsIgnoreCase(booknamee) && b.getId() == id);
    }
}