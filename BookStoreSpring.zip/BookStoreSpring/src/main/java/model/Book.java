package model;

public class Book {
    private int id;
    private String bookname;
    private String authname;

    public Book() {}

    public Book(int id, String bookname, String authname) {
        this.id = id;
        this.bookname = bookname;
        this.authname = authname;
    }

    public int getId() {
        return id;
    }

    public String getBookname() {
        return bookname;
    }

    public String getAuthname() {
        return authname;
    }

    @Override
    public String toString() {
        return "Book{" +
                "id=" + id +
                ", bookname='" + bookname + '\'' +
                ", authname='" + authname + '\'' +
                '}';
    }
}