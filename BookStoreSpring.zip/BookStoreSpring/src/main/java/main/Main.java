package main;

import config.AppConfig;
import model.Book;
import service.BookService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        BookService service = context.getBean(BookService.class);

        Scanner sc = new Scanner(System.in);
        int choice;

        do {
            System.out.print("1. Add Book  2. List Books  3. Search Book  4. Remove Book  5. Exit: ");
            choice = sc.nextInt(); sc.nextLine();

            switch (choice) {
                case 1:
                    System.out.print("Enter ID: ");
                    int id = sc.nextInt(); sc.nextLine();
                    System.out.print("Enter Book Name: ");
                    String name = sc.nextLine();
                    System.out.print("Enter Author Name: ");
                    String author = sc.nextLine();
                    service.addbook(new Book(id, name, author));
                    break;

                case 2:
                    service.getBook().forEach(System.out::println);
                    break;

                case 3:
                    System.out.print("Enter book name to search: ");
                    String searchName = sc.nextLine();
                    Book found = service.search(searchName);
                    if (found != null) System.out.println(found);
                    else System.out.println("Book not found!");
                    break;

                case 4:
                    System.out.print("Enter book name to remove: ");
                    String remove = sc.nextLine();
                    System.out.print("Enter book ID: ");
                    int removeId = sc.nextInt(); sc.nextLine();
                    service.removebook(remove, removeId);
                    break;
            }
        } while (choice != 5);

        sc.close();
    }
}